(function () {
  const header = document.getElementById("header");
  const toggle = document.getElementById("menu-toggle");
  const nav = document.getElementById("nav");

  function onScroll() {
    header.classList.toggle("is-scrolled", window.scrollY > 8);
  }

  toggle.addEventListener("click", function () {
    const open = nav.classList.toggle("is-open");
    toggle.classList.toggle("is-open", open);
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
  });

  nav.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () {
      nav.classList.remove("is-open");
      toggle.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
})();
